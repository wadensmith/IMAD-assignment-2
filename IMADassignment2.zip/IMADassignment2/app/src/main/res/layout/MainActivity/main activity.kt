package com .example.mealsuggester

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import.android.widget.EditText
        import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActvity : AppCompatActivity()

private lateinit var timeInput:EditText
private lateinit var suggesstionTextView: TextView
private lateinit var suggestButton: Button
private lateinit var resetButton: Button

override fun onCreate(savedInstanceState:Bundle)
super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Link UI elements
timeInput = findViewById(R.id.timeInput)
        suggestionText=
        findViewById(R.id.suggestionText)
        suggestionButton=
        findViewById(R.id.suggestsButton)
        resetButton=
        findViewById(R.id.resetButton)

        //Handle suggest button click
suggestButton.setOnClickListener{
    val timeOfDay:
            timeInput.text.toString().trim()
    //Suggest meal based on time
    if (timeOfDay.equals("morning" , ignoreCase = true)) {
        val SuggesstionText = null
        SuggesstionText.text = "breakfast ideas: Pancakes."
    } else if (timeOfDay.equals("Mid-morning" , ignoreCase = true)) {
        suggestionText.text = "snack Ideas:Fruit,yougurt."
    } else if (timeOfDay.equals("afternoon" , ignoreCase = true)) {
        suggesstionText.text = "Lunch ideas: sandwhich,stri fry, grilled cheese."
    } else if (timeOfDay.equals("Mid-afternoon" , ignoreCase = true)) {
        suggestionText.text = "Quick bite:Buscuits."
    } elseif (timeoDayequals("Dinner" , ignoreCase = true)){
        suggestionText.text = "Dinner ideas:Wrap,Pasta,Curry."
    } elseif (timeOfDay.equals("After Dinner" , ignoreCase = true)){
        suggestionText.text = "Dessert Ideas:Cake,muffins,chocolate."
    }else{
        // Error handling for invalid input
        Toast.makeText(
            this , "Please enter a valid time of day(e.g.,Morning,Afternoon),
                    Toast . LENGTH_SHORT
        ).show()
        suggesstionText.text = ""
    }
}
//Handle reset button click
resetButton.setOnClickListener{
    timeInput.text.clear()
    suggestionText.text = ""
   }
  }
}


    }

