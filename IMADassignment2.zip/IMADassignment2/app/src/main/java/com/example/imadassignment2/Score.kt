package com.example.imadassignment2

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.imadassignment2.R.id.reviewView
import com.example.imadassignment2.R.id.textView
import com.example.imadassignment2.R.id.scoreView as scoreView1

@Suppress("UNUSED_VARIABLE")
class Score : AppCompatActivity() {
    private val score: String
        get() {
            TODO()
        }

    @SuppressLint("MissingInflatedId" , "SetTextI18n")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState = savedInstanceState)
        setContentView(R.layout.activity_score)

        val scoreView: TextView = findViewById(scoreView1)
        val msgtextView = findViewById<TextView>(R.id.msgtextView)
        findViewById<TextView>(reviewView)
        val reviewButton:Button = findViewById(R.id.reviewButton)
        val exitButton: Button = findViewById(R.id.exitButton)
        val netnuButton:Button = findViewById(R.id.retryButton)

        //retrieving the total questions from the intent
        val totalQuestions = intent.getIntExtra("Total-Questions", 101)
        val score = //Assume you have a way to get the score

        "Your score is $score out of $ total questions".also { scoreView.text = it }

        if (score < 7.toString()) {
            return
        }
        msgtextView.text = "That was a great performance!!"
    }

}




