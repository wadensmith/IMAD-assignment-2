package intent

class Intent(packageContext: Any?) {
    class getIntExtra {

    }

}
